This project is tested with Xamarin Unity game which Android package name is `com.papegames.evol`.

## Requirements

Python 3

	pip install pillow unitypack lz4 fsb5

`etcpack.exe`, `libogg.dll`, `libvorbis.dll` are for Windows.

## Usage

	python ./extract.py -i <resource dir> -o <extract to here>
