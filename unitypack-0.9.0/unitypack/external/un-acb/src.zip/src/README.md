# un-acb
Simple command line program to extract HCA files from CRI ACB archives. Uses parts of VGMToolbox (http://sourceforge.net/projects/vgmtoolbox/) for extraction.

Usage: un-acb.exe path-to-acb-file [prefix-cue-id:false]
